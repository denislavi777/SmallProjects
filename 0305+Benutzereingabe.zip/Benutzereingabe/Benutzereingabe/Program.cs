﻿using System;

namespace Benutzereingabe
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine(Calculate());
            Console.ReadKey();
        }

        public static int Calculate()
        {
            Console.WriteLine("Bitte trage die erste Zahl ein.");
            string number1Input = Console.ReadLine();
            Console.WriteLine("Bitte trage die zweite Zahl ein.");
            string number2Input = Console.ReadLine();

            int num1 = int.Parse(number1Input);
            int num2 = int.Parse(number2Input);

            int result = num1 + num2;
            return result;
        }
    }
}
